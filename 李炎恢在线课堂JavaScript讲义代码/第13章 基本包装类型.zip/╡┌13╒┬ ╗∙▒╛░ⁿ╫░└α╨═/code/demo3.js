



/*
var box = 'Mr. Lee';
//alert(box.toLowerCase());		//Сд
//alert(box.toUpperCase());		//��д
alert(box.toLocaleLowerCase());
alert(box.toLocaleUpperCase());

//var box = 'Mr. Lee';
//alert(box.match('L'));		//�ҵ�L������L
//alert(box.match(','));			//û�ҵ�null
//alert(box.search('L'));		//�ҵ�L��λ��
//alert(box.replace('L', 'Q'));	//�滻
//alert(box.split(' '));		//�ָ������
//alert(String.fromCharCode(76));	//��һ��ascii��

//var box = 'Lee';
//alert(box.localeCompare('Lee'));	//0
//alert(box.localeCompare('Aee'));		//1
//alert(box.localeCompare('Zee'));		//-1
//alert(box.localeCompare('6576'));
//alert(box.localeCompare('��'));
//alert(box.localeCompare('��'));
*/


var box = '�ٶ�';
alert(box.link('http://www.baidu.com'));
alert(box.bold());









