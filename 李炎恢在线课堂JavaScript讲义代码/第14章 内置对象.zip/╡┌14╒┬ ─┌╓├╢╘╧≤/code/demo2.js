



/*
alert(Math.E);
alert(Math.PI);

alert(Math.min(2,5,8,4,9,2,0,1));
alert(Math.max(2,5,8,4,9,2,0,1));

//��������
alert(Math.ceil(25.9));
alert(Math.ceil(25.5));
alert(Math.ceil(25.1));

//��������
alert(Math.floor(25.9));
alert(Math.floor(25.5));
alert(Math.floor(25.1));

//��������
alert(Math.round(25.9));
alert(Math.round(25.5));
alert(Math.round(25.1));

alert(Math.random());

for (var i=0;i<10;i++) {
	document.write(Math.random());
	document.write('<br />');
}

for (var i=0;i<10;i++) {
	document.write(Math.floor(Math.random() * 10 + 1));		//��Χ1-10
	document.write('<br />');
}

for (var i=0;i<10;i++) {
	document.write(Math.floor(Math.random() * 10 + 5));		//��Χ5-14֮��  	10+5-1=14 (5-14)
	document.write('<br />');
}


//�������5-10֮�䣬����10 - 5 + 1 = 6

for (var i=0;i<10;i++) {
	document.write(Math.floor(Math.random() * 6 + 5));			//5-10   6 + 5 - 1 = 10  (5-10)
	document.write('<br />');
}

function select(start, end) {
	var total = end - start + 1;
	return Math.floor(Math.random() * total + start);
}


for (var i=0;i<10;i++) {
	document.write(select(1, 3));			//��Χ5-10	
	document.write('<br />');
}

alert(Math.abs(-5));
alert(Math.sqrt(9));

*/














